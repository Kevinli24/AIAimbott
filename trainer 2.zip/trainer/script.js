const animalBox = document.getElementById('animalBox');
const animalImage = document.querySelector('.animal-image');
const statusElement = document.getElementById('status');
const resultElement = document.getElementById('result');
const catSound = document.getElementById('catSound');
const dogSound = document.getElementById('dogSound');
const speedControl = document.getElementById('speed');
const soundToggle = document.getElementById('soundToggle');

let currentAnimal = '';
let isSoundOn = true;
let animationTimeout;
let movementSteps = [];
const animationSequence = [
    { pos: '50%', duration: 800 },   // Center
    { pos: '10%', duration: 1200 },  // Left
    { pos: '90%', duration: 1200 },  // Right
    { pos: '50%', duration: 1000 }   // Return center
];

// Initialize
window.addEventListener('DOMContentLoaded', async () => {
    catSound.volume = 0.5;
    dogSound.volume = 0.5;
    await loadNewAnimal();
    startAnimation();
    setupControls();
});

function setupControls() {
    // Sound toggle
    soundToggle.addEventListener('click', () => {
        isSoundOn = !isSoundOn;
        soundToggle.textContent = isSoundOn ? '🔊 Sound On' : '🔇 Sound Off';
    });

    // Speed control
    speedControl.addEventListener('input', (e) => {
        const speed = e.target.value;
        animalBox.style.transitionDuration = `${800 / speed}ms`;
    });
}

async function loadNewAnimal() {
    const isCat = Math.random() > 0.5;
    const apiUrl = isCat ? 
        'https://api.thecatapi.com/v1/images/search' :
        'https://api.thedogapi.com/v1/images/search';

    try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        currentAnimal = isCat ? 'cat' : 'dog';
        animalImage.src = data[0].url;
        statusElement.textContent = `Current animal: ${currentAnimal}`;
    } catch (error) {
        console.error('Error fetching image:', error);
        animalImage.src = 'fallback.jpg';
    }
}

function playAnimalSound() {
    if (!isSoundOn) return;
    
    const sound = currentAnimal === 'cat' ? catSound : dogSound;
    sound.currentTime = 0;
    sound.play().catch(error => {
        console.log('Audio playback prevented:', error);
    });
}

async function startAnimation() {
    for (const step of animationSequence) {
        await moveAnimal(step);
    }
    startRandomMovement();
}

async function moveAnimal({ pos, duration }) {
    animalBox.style.left = pos;
    animalBox.style.transform = `translateX(-${pos === '90%' ? '100%' : '50%'})`;
    
    await new Promise(resolve => {
        animationTimeout = setTimeout(resolve, duration);
    });
}

function startRandomMovement() {
    const randomDirection = Math.random() > 0.5 ? '10%' : '90%';
    animalBox.style.left = randomDirection;
    animalBox.style.transform = `translateX(-${randomDirection === '90%' ? '100%' : '0%'})`;
    
    animationTimeout = setTimeout(() => {
        startAnimation();
    }, 1500);
}

// Click handler
animalBox.addEventListener('click', async (event) => {
    // Show result
    resultElement.textContent = `You clicked a ${currentAnimal}!`;
    resultElement.style.color = currentAnimal === 'cat' ? '#FF5722' : '#3F51B5';

    // Visual feedback
    animalBox.classList.add('click-effect');
    setTimeout(() => {
        animalBox.classList.remove('click-effect');
    }, 300);

    // Play sound
    playAnimalSound();

    // Reset animation
    clearTimeout(animationTimeout);
    animalBox.style.transition = 'none';
    await loadNewAnimal();
    animalBox.style.transition = 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)';
    startAnimation();
});